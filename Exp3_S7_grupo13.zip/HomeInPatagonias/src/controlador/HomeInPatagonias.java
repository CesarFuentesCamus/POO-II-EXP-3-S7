
package controlador;


import vista.Agregar;
import vista.Eliminar;
import vista.Listar;
import vista.Modificar;


public class HomeInPatagonias {

    
    public static void main(String[] args) {
        
        new Agregar().setVisible(true);
        new Modificar().setVisible(true);
        new Eliminar().setVisible(true);
        new Listar().setVisible(true);
      
       
    }
    
    
}
